-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql201.infinityfree.com
-- Generation Time: Nov 19, 2026 at 06:04 PM
-- Server version: 11.4.13-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_43472678_jobili`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'General'),
(2, 'Beverages'),
(3, 'Snacks'),
(4, 'Household'),
(5, 'Personal Care');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `phone`, `address`, `notes`, `created_at`) VALUES
(2, 'john', '0912345677', 'john', 'babayadan sa katapusan \r\ncoke\r\n1kg chicken \r\n5pcs piatos', '2026-11-19 05:49:27'),
(4, 'RJ', '09123676767', 'bulacan', '10pcs Redhorse\r\n3kg chicken\r\nDatuputi suka\r\ndatuputi toyo\r\npalmolive 12pcs shampoo\r\nbabayaran sa katapusan', '2026-11-19 05:55:05'),
(5, 'jazztine', '09123456767', 'jazz@gmail.com', NULL, '2026-11-19 07:10:38'),
(6, 'sigabo', '09123456789', 'barangay piti piwpiw', NULL, '2026-11-19 13:01:40'),
(7, 'jazz', '09999999999', 'pitipiwpiw', 'babayaran din sa katapusan', '2026-11-19 13:54:45'),
(8, 'qqqq', '22222222', 'wwwwwwww', NULL, '2026-11-19 14:31:12'),
(9, 'Len', '09123456761', 'Malolos', NULL, '2026-11-19 21:06:49');

-- --------------------------------------------------------

--
-- Table structure for table `customer_accounts`
--

CREATE TABLE `customer_accounts` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `email` varchar(190) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `customer_accounts`
--

INSERT INTO `customer_accounts` (`id`, `customer_id`, `email`, `password_hash`, `created_at`) VALUES
(1, 5, 'jazz@gmail.com', '$2y$12$q1q6UMvmoX4IG1cdLlM0a.aNL.Jdcvfa7XhXc/q6ZEjLYRUadProi', '2026-11-19 07:10:39'),
(2, 6, 'bayagra@gmail.com', '$2y$12$LaCDnNG980c8NwhcaXSKgOfEonP58YXJ5fNNjfab7FDlDGRHQ1LNS', '2026-11-19 13:01:40'),
(3, 8, 'qqqqqqqqqqq@gmail.com', '$2y$12$7vcPp88uANYIqeo8jT2NceApT0NiR7zkpfKbj2tXGtIDRUYR77dxW', '2026-11-19 14:31:12'),
(4, 9, 'lenlen@gmail.com', '$2y$12$dIqutkGR2GLVU73Xh7aRDeZ.S10QYv5SR5s6bnhshrbLOIrO5tso2', '2026-11-19 21:06:49');

-- --------------------------------------------------------

--
-- Table structure for table `customer_notification_reads`
--

CREATE TABLE `customer_notification_reads` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `order_status` varchar(30) NOT NULL,
  `read_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `customer_notification_reads`
--

INSERT INTO `customer_notification_reads` (`id`, `customer_id`, `order_id`, `order_status`, `read_at`) VALUES
(1, 5, 8, 'Completed', '2026-11-19 22:33:35'),
(2, 5, 7, 'Completed', '2026-11-19 22:33:35'),
(3, 5, 6, 'Completed', '2026-11-19 22:33:35'),
(4, 5, 5, 'Cancelled', '2026-11-19 22:33:35'),
(5, 5, 4, 'Cancelled', '2026-11-19 22:33:35'),
(6, 9, 13, 'Completed', '2026-11-19 22:46:11'),
(7, 9, 12, 'Completed', '2026-11-19 22:46:11');

-- --------------------------------------------------------

--
-- Table structure for table `customer_product_requests`
--

CREATE TABLE `customer_product_requests` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `product_name` varchar(150) NOT NULL,
  `preferred_quantity` int(11) NOT NULL DEFAULT 1,
  `details` text DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customer_wishlist`
--

CREATE TABLE `customer_wishlist` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `debt_payments`
--

CREATE TABLE `debt_payments` (
  `id` bigint(20) NOT NULL,
  `sale_id` bigint(20) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `debt_payments`
--

INSERT INTO `debt_payments` (`id`, `sale_id`, `amount`, `user_id`, `notes`, `paid_at`) VALUES
(1, 1, '500.00', 1, 'Payment', '2026-11-19 05:50:59'),
(2, 4, '19.99', 1, 'Payment', '2026-11-19 07:44:23'),
(3, 2, '1000.00', 1, 'Payment', '2026-11-19 12:16:50'),
(4, 4, '0.01', 1, 'Payment', '2026-11-19 12:18:25');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` bigint(20) NOT NULL,
  `title` varchar(150) NOT NULL,
  `category` varchar(80) NOT NULL DEFAULT 'General',
  `amount` decimal(12,2) NOT NULL,
  `notes` text DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `expense_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`id`, `title`, `category`, `amount`, `notes`, `user_id`, `expense_date`, `created_at`) VALUES
(2, 'Electric bill', 'Utilities', '3543.00', '', 1, '2026-12-01', '2026-11-19 22:49:05'),
(3, 'Gas', 'Transport', '900.00', '', 1, '2026-11-19', '2026-11-19 22:49:34'),
(4, 'All products', 'Supplies', '61946.85', 'Estimate 62000-65000', 1, '2026-11-19', '2026-11-19 22:53:29'),
(5, 'Cashier', 'General', '14750.00', '25 days', 1, '2026-11-19', '2026-11-19 22:54:39');

-- --------------------------------------------------------

--
-- Table structure for table `inventory_logs`
--

CREATE TABLE `inventory_logs` (
  `id` bigint(20) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `change_qty` int(11) NOT NULL,
  `reason` varchar(180) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `inventory_logs`
--

INSERT INTO `inventory_logs` (`id`, `product_id`, `user_id`, `change_qty`, `reason`, `created_at`) VALUES
(1, 6, 1, -15, 'Sale JB-261119-0DF2B7', '2026-11-19 06:39:29'),
(2, 5, 1, -1, 'Online Order Accepted - JB-20261119-0F3EE0', '2026-11-19 10:53:38'),
(3, 5, 1, -1, 'Sale JB-261119-D2560B', '2026-11-19 11:19:31'),
(4, 5, 1, -1, 'Online Order Accepted - JB-20261119-100416', '2026-11-19 11:45:30'),
(5, 5, 1, -1, 'Online Order Accepted - JB-20261119-812C9E', '2026-11-19 11:47:59'),
(6, 7, 1, 50, 'Stock adjustment', '2026-11-19 12:11:31'),
(7, 5, 1, -3, 'Sale JB-261119-ECE013', '2026-11-19 12:26:11'),
(8, 10, 1, -3, 'Sale JB-261119-6567C1', '2026-11-19 12:28:38'),
(9, 10, 1, -2, 'Sale JB-261119-E76695', '2026-11-19 12:29:06'),
(10, 9, 1, -1, 'Online Order Accepted - JB-20261119-FB0221', '2026-11-19 13:10:06'),
(11, 13, 1, -3, 'Utang JB-UTANG-261119082931-8262', '2026-11-19 13:29:32'),
(12, 12, 1, -5, 'Utang JB-UTANG-261119082931-8262', '2026-11-19 13:29:32'),
(13, 6, 1, -1, 'Utang JB-UTANG-261119085514-7CE8', '2026-11-19 13:55:15'),
(14, 9, 1, -1, 'Online Order Accepted - JB-20261119-9A90C1', '2026-11-19 14:28:21'),
(15, 13, 1, -1, 'Online Order Accepted - JB-20261119-9A90C1', '2026-11-19 14:28:21'),
(16, 7, 1, -1, 'Online Order Accepted - JB-20261119-38E3C3', '2026-11-19 15:46:02'),
(17, 9, 1, -1, 'Online Order Accepted - JB-20261119-38E3C3', '2026-11-19 15:46:02'),
(18, 14, 2, -1, 'Online Order Accepted - JB-20261120-2843DD', '2026-11-19 21:10:25'),
(19, 13, 2, -1, 'Online Order Accepted - JB-20261120-719E60', '2026-11-19 21:55:07'),
(20, 14, 2, -2, 'Online Order Accepted - JB-20261120-719E60', '2026-11-19 21:55:07'),
(21, 17, 2, -1, 'Online Order Accepted - JB-20261120-719E60', '2026-11-19 21:55:07'),
(22, 7, 1, -4, 'Sale JB-261119-12391B', '2026-11-19 22:56:56'),
(23, 8, 1, -4, 'Sale JB-261119-12391B', '2026-11-19 22:56:56'),
(24, 9, 1, -5, 'Sale JB-261119-12391B', '2026-11-19 22:56:56'),
(25, 10, 1, -5, 'Sale JB-261119-12391B', '2026-11-19 22:56:56'),
(26, 11, 1, -5, 'Sale JB-261119-12391B', '2026-11-19 22:56:56'),
(27, 12, 1, -21, 'Sale JB-261119-12391B', '2026-11-19 22:56:56'),
(28, 13, 1, -4, 'Sale JB-261119-12391B', '2026-11-19 22:56:56'),
(29, 15, 1, -2, 'Sale JB-261119-12391B', '2026-11-19 22:56:56'),
(30, 17, 1, -3, 'Sale JB-261119-12391B', '2026-11-19 22:56:56'),
(31, 23, 1, -6, 'Sale JB-261119-12391B', '2026-11-19 22:56:56'),
(32, 24, 1, -3, 'Sale JB-261119-12391B', '2026-11-19 22:56:56'),
(33, 25, 1, -8, 'Sale JB-261119-12391B', '2026-11-19 22:56:56'),
(34, 26, 1, -4, 'Sale JB-261119-12391B', '2026-11-19 22:56:56'),
(35, 27, 1, -5, 'Sale JB-261119-12391B', '2026-11-19 22:56:56'),
(36, 28, 1, -5, 'Sale JB-261119-12391B', '2026-11-19 22:56:56'),
(37, 29, 1, -3, 'Sale JB-261119-12391B', '2026-11-19 22:56:56');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `order_number` varchar(50) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(150) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `address` varchar(255) NOT NULL,
  `pickup_date` date NOT NULL,
  `pickup_time` time NOT NULL,
  `pickup_branch` varchar(100) NOT NULL DEFAULT 'Bulacan Branch',
  `total_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `order_status` varchar(30) NOT NULL DEFAULT 'Pending',
  `payment_status` varchar(30) NOT NULL DEFAULT 'Unpaid',
  `payment_method` varchar(50) NOT NULL DEFAULT 'Pay at Store',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `stock_deducted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `order_number`, `customer_id`, `customer_name`, `phone`, `address`, `pickup_date`, `pickup_time`, `pickup_branch`, `total_amount`, `order_status`, `payment_status`, `payment_method`, `notes`, `created_at`, `stock_deducted`) VALUES
(1, 'JB-20261119-0DC1E1', 5, 'jazztine', '09123456767', 'jazz@gmail.com', '2026-11-19', '22:00:00', 'Malolos Bayan Branch', '93.00', 'Cancelled', 'Unpaid', 'Pay at Store', NULL, '2026-11-19 09:33:47', 0),
(2, 'JB-20261119-EA652D', 5, 'jazztine', '09123456767', 'jazz@gmail.com', '2026-11-19', '22:30:00', 'Bulacan Branch', '26.00', 'Cancelled', 'Unpaid', 'Pay at Store', NULL, '2026-11-19 09:35:26', 0),
(3, 'JB-20261119-A8BEC6', 5, 'jazztine', '09123456767', 'jazz@gmail.com', '2026-12-16', '22:30:00', 'Malolos Bayan Branch', '7.00', 'Cancelled', 'Unpaid', 'Pay at Store', NULL, '2026-11-19 09:44:24', 0),
(4, 'JB-20261119-34598A', 5, 'jazztine', '09123456767', 'jazz@gmail.com', '2026-12-01', '23:30:00', 'Bulacan Branch', '12.00', 'Cancelled', 'Unpaid', 'Pay at Store', NULL, '2026-11-19 09:49:52', 0),
(5, 'JB-20261119-E7A341', 5, 'jazztine', '09123456767', 'jazz@gmail.com', '2026-12-01', '15:30:00', 'Malolos Bayan Branch', '12.00', 'Cancelled', 'Unpaid', 'Pay at Store', NULL, '2026-11-19 09:52:16', 0),
(6, 'JB-20261119-0F3EE0', 5, 'jazztine', '09123456767', 'jazz@gmail.com', '2026-12-01', '15:30:00', 'Malolos Bayan Branch', '12.00', 'Completed', 'Paid', 'Pay at Store', NULL, '2026-11-19 09:54:09', 1),
(7, 'JB-20261119-100416', 5, 'Sir Jazztine', '09123456767', 'jazz@gmail.com', '2026-11-19', '23:30:00', 'Malolos Bayan Branch', '12.00', 'Completed', 'Paid', 'cash', NULL, '2026-11-19 11:45:04', 1),
(8, 'JB-20261119-812C9E', 5, 'jazztine', '09123456767', 'jazz@gmail.com', '2026-11-19', '22:30:00', 'Bulacan Branch', '12.00', 'Completed', 'Paid', 'cash', NULL, '2026-11-19 11:47:42', 1),
(9, 'JB-20261119-FB0221', 6, 'sigabo', '09123456789', 'barangay piti piwpiw', '2026-11-20', '08:30:00', 'Bulacan Branch', '26.00', 'Completed', 'Paid', 'gcash', NULL, '2026-11-19 13:09:26', 1),
(10, 'JB-20261119-9A90C1', 6, 'sigabo', '09123456789', 'barangay piti piwpiw', '2026-11-27', '09:30:00', 'Bulacan Branch', '166.00', 'Completed', 'Paid', 'cash', NULL, '2026-11-19 14:28:10', 1),
(11, 'JB-20261119-38E3C3', 8, 'qqqq', '22222222', 'wwwwwwww', '2026-11-30', '13:30:00', 'Bulacan Branch', '46.00', 'Completed', 'Paid', 'cash', NULL, '2026-11-19 14:33:25', 1),
(12, 'JB-20261120-2843DD', 9, 'Len', '09123456761', 'Malolos', '2026-11-20', '08:00:00', 'Malolos Bayan Branch', '15.00', 'Completed', 'Paid', 'cash', NULL, '2026-11-19 21:07:51', 1),
(13, 'JB-20261120-719E60', 9, 'Len', '09123456761', 'Malolos', '2026-11-20', '08:00:00', 'Malolos Bayan Branch', '410.00', 'Completed', 'Paid', 'cash', NULL, '2026-11-19 21:54:47', 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(150) NOT NULL,
  `sku` varchar(60) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `product_name`, `sku`, `quantity`, `unit_price`, `subtotal`, `created_at`) VALUES
(1, 1, 6, 'chippy', '02', 3, '7.00', '21.00', '2026-11-19 09:33:47'),
(2, 1, 5, 'piatos', '01', 6, '12.00', '72.00', '2026-11-19 09:33:47'),
(3, 2, 6, 'chippy', '02', 2, '7.00', '14.00', '2026-11-19 09:35:26'),
(4, 2, 5, 'piatos', '01', 1, '12.00', '12.00', '2026-11-19 09:35:26'),
(5, 3, 6, 'chippy', '02', 1, '7.00', '7.00', '2026-11-19 09:44:24'),
(6, 4, 5, 'piatos', '01', 1, '12.00', '12.00', '2026-11-19 09:49:52'),
(7, 5, 5, 'piatos', '01', 1, '12.00', '12.00', '2026-11-19 09:52:16'),
(8, 6, 5, 'piatos', '01', 1, '12.00', '12.00', '2026-11-19 09:54:09'),
(9, 7, 5, 'piatos', '01', 1, '12.00', '12.00', '2026-11-19 11:45:04'),
(10, 8, 5, 'piatos', '01', 1, '12.00', '12.00', '2026-11-19 11:47:42'),
(11, 9, 9, 'kopiko lucky day', '003', 1, '26.00', '26.00', '2026-11-19 13:09:26'),
(12, 10, 9, 'kopiko lucky day', '003', 1, '26.00', '26.00', '2026-11-19 14:28:10'),
(13, 10, 13, 'chicken 1kg', '67', 1, '140.00', '140.00', '2026-11-19 14:28:10'),
(14, 11, 7, 'coca cola mismo', '001', 1, '20.00', '20.00', '2026-11-19 14:33:25'),
(15, 11, 9, 'kopiko lucky day', '003', 1, '26.00', '26.00', '2026-11-19 14:33:25'),
(16, 12, 14, 'bottled water', '00001', 1, '15.00', '15.00', '2026-11-19 21:07:51'),
(17, 13, 14, 'Bottled Water', '00001', 2, '15.00', '30.00', '2026-11-19 21:54:47'),
(18, 13, 13, 'Chicken 1kg', '00002', 1, '140.00', '140.00', '2026-11-19 21:54:47'),
(19, 13, 17, 'Head And Shoulders Shampoo', '00013', 1, '240.00', '240.00', '2026-11-19 21:54:47');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `sku` varchar(60) DEFAULT NULL,
  `name` varchar(150) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `cost` decimal(12,2) NOT NULL DEFAULT 0.00,
  `stock` int(11) NOT NULL DEFAULT 0,
  `reorder_level` int(11) NOT NULL DEFAULT 5,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `sku`, `name`, `category_id`, `price`, `cost`, `stock`, `reorder_level`, `active`, `created_at`, `image`) VALUES
(1, '020123', 'joy dishwashing  1liter', 4, '60.00', '40.00', 30, 5, 0, '2026-11-18 21:42:35', '46ed96442dec0d8ccf63b8d7077fafad.jpg'),
(5, '00009', 'Piattos 40g', 3, '22.75', '16.25', 53, 5, 1, '2026-11-19 06:00:47', '09a2861a0fabafff3e7a008a45291f19.png'),
(6, '00003', 'Chippy 25g', 3, '9.80', '7.00', 199, 5, 1, '2026-11-19 06:37:24', '87d4208ca56e3a5fdad896382f8477e5.webp'),
(7, '00004', 'COCA COLA Mismo 290ml', 2, '25.20', '18.00', 50, 5, 1, '2026-11-19 12:05:13', '05137527b206b8514335ba30bc48c034.png'),
(8, '00006', 'Lucky Me PANCIT CANTON 80g', 1, '19.25', '13.75', 46, 5, 1, '2026-11-19 12:10:49', 'ce0148167127ee5703a739e7da23989a.webp'),
(9, '00005', 'KOPIKO LUCKY DAY 180ml', 2, '36.40', '26.40', 42, 5, 1, '2026-11-19 12:16:32', 'f2e1a678f18fc8dd695ba95b0ded4963.png'),
(10, '00008', 'OREO 133g', 3, '65.10', '46.50', 40, 5, 1, '2026-11-19 12:22:07', 'e67cf313f2a28d36cef6e8fdc26739bb.webp'),
(11, '00007', 'Oishi Prawn Crackers 60g', 3, '19.60', '14.00', 45, 5, 1, '2026-11-19 12:24:10', '88b0c5543966023a05a0e8368e7f1d59.png'),
(12, '00010', 'Redhorse Mucho 1l', 2, '182.00', '130.00', 174, 5, 1, '2026-11-19 13:24:29', 'e8083028e613b16aff60c6f4b8986345.png'),
(13, '00002', 'Chicken 1kg', 1, '137.20', '98.00', 111, 5, 1, '2026-11-19 13:27:46', '534c344974041d51904a3422fe24bd91.webp'),
(14, '00001', 'Bottled Water 200ml', 2, '12.60', '9.00', 197, 5, 1, '2026-11-19 20:23:56', 'd9520a2f1938fbcfc91e349677731094.png'),
(15, '00011', 'Boy Bawang 100g', 3, '33.80', '22.00', 48, 5, 1, '2026-11-19 20:27:18', 'c1372bca92706abb09d3a37d662709f9.webp'),
(16, '00012', 'Dove Soap 90g', 5, '84.00', '60.00', 50, 5, 1, '2026-11-19 20:28:40', '6e167b553772e7dd0ade2256d9b886ec.webp'),
(17, '00013', 'Head And Shoulders Shampoo 170ml', 5, '261.00', '187.00', 46, 5, 1, '2026-11-19 20:31:31', 'b55d73e41d71896536272953433463be.png'),
(18, '00014', 'Mountain Dew 290ml', 3, '23.80', '17.00', 50, 5, 1, '2026-11-19 20:34:05', 'd34e564f9f242575815f918b642590fd.png'),
(20, '00015', 'NOVA 40g', 3, '21.00', '15.00', 50, 5, 1, '2026-11-19 20:39:45', 'e21c9a9a5db7430dad9c7d4b3d4fca91.png'),
(21, '00016', 'Palmolive Shampoo 15ml', 5, '8.40', '6.00', 80, 5, 1, '2026-11-19 20:43:18', '3480dcfab126edfb1e4f42801cd74a64.png'),
(23, '00017', 'RC Mega 800ml', 3, '33.60', '24.00', 44, 5, 1, '2026-11-19 20:45:36', '8d9ee157e14f1ca9fce8756ae6f6158e.png'),
(24, '00018', 'Royal 320ml', 3, '35.00', '25.00', 76, 5, 1, '2026-11-19 20:47:34', '127e39804b73dba5a55b221b86302b99.webp'),
(25, '00019', 'Safe Guard 85g', 5, '74.00', '53.00', 42, 5, 1, '2026-11-19 20:52:59', '814616324cff0ad6e7e639e4c97837ea.webp'),
(26, '00020', 'Sprite 190ml', 3, '20.30', '14.50', 76, 5, 1, '2026-11-19 20:58:48', '24e4ae380b0902cb0956575e67457c86.webp'),
(27, '00021', 'Red cups 12oz 25pcs', 4, '49.00', '35.00', 65, 5, 1, '2026-11-19 21:25:30', '64c2f83c8d953970933a7e1253758150.png'),
(28, '00022', 'Disposable plates 35pcs', 4, '56.00', '40.00', 55, 5, 1, '2026-11-19 21:28:35', 'ec027c2e1fe5c82fbaa0bb1cb0a05952.webp'),
(29, '00023', 'Joy 36ml', 4, '7.00', '5.00', 32, 5, 1, '2026-11-19 21:34:40', '24ad6fa3759daab9009f6f467003f696.webp');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` bigint(20) NOT NULL,
  `receipt_no` varchar(40) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  `discount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total` decimal(12,2) NOT NULL,
  `amount_paid` decimal(12,2) NOT NULL DEFAULT 0.00,
  `change_due` decimal(12,2) NOT NULL DEFAULT 0.00,
  `payment_method` enum('cash','utang','gcash','bank') NOT NULL DEFAULT 'cash',
  `status` enum('paid','utang','void') NOT NULL DEFAULT 'paid',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `online_order_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `receipt_no`, `customer_id`, `user_id`, `subtotal`, `discount`, `total`, `amount_paid`, `change_due`, `payment_method`, `status`, `created_at`, `online_order_id`) VALUES
(1, 'JB-UTANG-261119005012-53A6', 2, 1, '500.00', '0.00', '500.00', '500.00', '0.00', 'utang', 'paid', '2026-11-19 05:50:12', NULL),
(2, 'JB-UTANG-261119005520-24F8', 4, 1, '1000.00', '0.00', '1000.00', '1000.00', '0.00', 'utang', 'paid', '2026-11-19 05:55:21', NULL),
(3, 'JB-261119-0DF2B7', NULL, 1, '105.00', '0.00', '105.00', '150.00', '45.00', 'cash', 'paid', '2026-11-19 06:39:29', NULL),
(4, 'JB-UTANG-261119024335-DE1A', 5, 1, '20.00', '0.00', '20.00', '20.00', '0.00', 'utang', 'paid', '2026-11-19 07:43:36', NULL),
(5, 'JB-261119-D2560B', NULL, 1, '12.00', '0.00', '12.00', '12.00', '0.00', 'cash', 'paid', '2026-11-19 11:19:31', NULL),
(6, 'JB-261119-B5558B', 5, 1, '12.00', '0.00', '12.00', '12.00', '0.00', 'cash', 'paid', '2026-11-19 11:46:51', 7),
(7, 'JB-261119-C616F0', 5, 1, '12.00', '0.00', '12.00', '12.00', '0.00', 'cash', 'paid', '2026-11-19 11:50:06', 8),
(8, 'JB-261119-ECE013', NULL, 1, '36.00', '0.00', '36.00', '36.00', '0.00', 'cash', 'paid', '2026-11-19 12:26:11', NULL),
(9, 'JB-261119-6567C1', NULL, 1, '144.00', '0.00', '144.00', '200.00', '56.00', 'cash', 'paid', '2026-11-19 12:28:38', NULL),
(10, 'JB-261119-E76695', NULL, 1, '96.00', '0.00', '96.00', '96.00', '0.00', 'cash', 'paid', '2026-11-19 12:29:06', NULL),
(11, 'JB-261119-DEF237', 6, 1, '26.00', '0.00', '26.00', '26.00', '0.00', 'gcash', 'paid', '2026-11-19 13:12:42', 9),
(12, 'JB-UTANG-261119082931-8262', 4, 1, '865.00', '0.00', '865.00', '0.00', '0.00', 'utang', 'utang', '2026-11-19 13:29:32', NULL),
(13, 'JB-UTANG-261119085514-7CE8', 7, 1, '7.00', '0.00', '7.00', '0.00', '0.00', 'utang', 'utang', '2026-11-19 13:55:15', NULL),
(14, 'JB-261119-0A158A', 6, 1, '166.00', '0.00', '166.00', '166.00', '0.00', 'cash', 'paid', '2026-11-19 15:46:12', 10),
(15, 'JB-261119-F39264', 8, 1, '46.00', '0.00', '46.00', '46.00', '0.00', 'cash', 'paid', '2026-11-19 15:46:21', 11),
(16, 'JB-261119-BD5F3B', 9, 2, '15.00', '0.00', '15.00', '15.00', '0.00', 'cash', 'paid', '2026-11-19 21:10:49', 12),
(17, 'JB-261119-87A51F', 9, 2, '410.00', '0.00', '410.00', '410.00', '0.00', 'cash', 'paid', '2026-11-19 21:55:22', 13),
(18, 'JB-261119-12391B', NULL, 1, '7530.50', '0.00', '7530.50', '8000.00', '469.50', 'cash', 'paid', '2026-11-19 22:56:56', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sale_items`
--

CREATE TABLE `sale_items` (
  `id` bigint(20) NOT NULL,
  `sale_id` bigint(20) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `product_name` varchar(150) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `unit_cost` decimal(12,2) NOT NULL DEFAULT 0.00,
  `line_total` decimal(12,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `sale_items`
--

INSERT INTO `sale_items` (`id`, `sale_id`, `product_id`, `product_name`, `quantity`, `unit_price`, `unit_cost`, `line_total`) VALUES
(1, 3, 6, 'chippy', 15, '7.00', '145.00', '105.00'),
(2, 5, 5, 'piatos', 1, '12.00', '250.00', '12.00'),
(3, 6, 5, 'piatos', 1, '12.00', '250.00', '12.00'),
(4, 7, 5, 'piatos', 1, '12.00', '250.00', '12.00'),
(5, 8, 5, 'piatos', 3, '12.00', '8.00', '36.00'),
(6, 9, 10, 'oreo', 3, '48.00', '38.00', '144.00'),
(7, 10, 10, 'oreo', 2, '48.00', '38.00', '96.00'),
(8, 11, 9, 'kopiko lucky day', 1, '26.00', '22.00', '26.00'),
(9, 12, 13, 'chicken 1kg', 3, '140.00', '100.00', '420.00'),
(10, 12, 12, 'Redhorse Macho 1L', 5, '89.00', '70.00', '445.00'),
(11, 13, 6, 'chippy', 1, '7.00', '5.00', '7.00'),
(12, 14, 9, 'kopiko lucky day', 1, '26.00', '22.00', '26.00'),
(13, 14, 13, 'chicken 1kg', 1, '140.00', '100.00', '140.00'),
(14, 15, 7, 'coca cola mismo', 1, '20.00', '17.00', '20.00'),
(15, 15, 9, 'kopiko lucky day', 1, '26.00', '22.00', '26.00'),
(16, 16, 14, 'bottled water', 1, '15.00', '9.00', '15.00'),
(17, 17, 14, 'Bottled Water', 2, '15.00', '9.00', '30.00'),
(18, 17, 13, 'Chicken 1kg', 1, '140.00', '100.00', '140.00'),
(19, 17, 17, 'Head And Shoulders Shampoo', 1, '240.00', '203.00', '240.00'),
(20, 18, 7, 'COCA COLA Mismo 290ml', 4, '25.20', '18.00', '100.80'),
(21, 18, 8, 'Lucky Me PANCIT CANTON 80g', 4, '19.25', '13.75', '77.00'),
(22, 18, 9, 'KOPIKO LUCKY DAY 180ml', 5, '36.40', '26.40', '182.00'),
(23, 18, 10, 'OREO 133g', 5, '65.10', '46.50', '325.50'),
(24, 18, 11, 'Oishi Prawn Crackers 60g', 5, '19.60', '14.00', '98.00'),
(25, 18, 12, 'Redhorse Mucho 1l', 21, '182.00', '130.00', '3822.00'),
(26, 18, 13, 'Chicken 1kg', 4, '137.20', '98.00', '548.80'),
(27, 18, 15, 'Boy Bawang 100g', 2, '33.80', '22.00', '67.60'),
(28, 18, 17, 'Head And Shoulders Shampoo 170ml', 3, '261.00', '187.00', '783.00'),
(29, 18, 23, 'RC Mega 800ml', 6, '33.60', '24.00', '201.60'),
(30, 18, 24, 'Royal 320ml', 3, '35.00', '25.00', '105.00'),
(31, 18, 25, 'Safe Guard 85g', 8, '74.00', '53.00', '592.00'),
(32, 18, 26, 'Sprite 190ml', 4, '20.30', '14.50', '81.20'),
(33, 18, 27, 'Red cups 12oz 25pcs', 5, '49.00', '35.00', '245.00'),
(34, 18, 28, 'Disposable plates 35pcs', 5, '56.00', '40.00', '280.00'),
(35, 18, 29, 'Joy 36ml', 3, '7.00', '5.00', '21.00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(60) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('owner','cashier') NOT NULL DEFAULT 'cashier',
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password_hash`, `role`, `created_at`) VALUES
(1, 'BSCS', 'owner', '$2y$12$kE33pp5mUiPV/559N7rbE.WM5nt9guer2sIqO6KSP9LYwUPSYpPWy', 'owner', '2026-11-18 21:35:01'),
(2, 'Cashier', 'cashier', '$2y$12$UTxGEiK/QcG8i.HR0GEcUOINBDSGgsTKDOk6nIbx7k3gm6FqVIZVq', 'cashier', '2026-11-18 21:35:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_accounts`
--
ALTER TABLE `customer_accounts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `customer_id` (`customer_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `customer_notification_reads`
--
ALTER TABLE `customer_notification_reads`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_notification` (`customer_id`,`order_id`,`order_status`);

--
-- Indexes for table `customer_product_requests`
--
ALTER TABLE `customer_product_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_customer` (`customer_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_product_name` (`product_name`);

--
-- Indexes for table `customer_wishlist`
--
ALTER TABLE `customer_wishlist`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_customer_product` (`customer_id`,`product_id`),
  ADD KEY `idx_customer` (`customer_id`),
  ADD KEY `idx_product` (`product_id`);

--
-- Indexes for table `debt_payments`
--
ALTER TABLE `debt_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sale_id` (`sale_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `expense_date` (`expense_date`);

--
-- Indexes for table `inventory_logs`
--
ALTER TABLE `inventory_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `order_number` (`order_number`),
  ADD KEY `idx_customer_id` (`customer_id`),
  ADD KEY `idx_order_status` (`order_status`),
  ADD KEY `idx_pickup_date` (`pickup_date`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_order_id` (`order_id`),
  ADD KEY `idx_product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sku` (`sku`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `name` (`name`),
  ADD KEY `active` (`active`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `receipt_no` (`receipt_no`),
  ADD UNIQUE KEY `uq_sales_online_order_id` (`online_order_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `created_at` (`created_at`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `sale_items`
--
ALTER TABLE `sale_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sale_id` (`sale_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `customer_accounts`
--
ALTER TABLE `customer_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customer_notification_reads`
--
ALTER TABLE `customer_notification_reads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `customer_product_requests`
--
ALTER TABLE `customer_product_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer_wishlist`
--
ALTER TABLE `customer_wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `debt_payments`
--
ALTER TABLE `debt_payments`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `inventory_logs`
--
ALTER TABLE `inventory_logs`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `sale_items`
--
ALTER TABLE `sale_items`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
